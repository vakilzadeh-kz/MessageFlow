package com.smsmanager.util

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat

object NotificationHelper {
    fun showNotification(context: Context, title: String, message: String) {
        // Build and show notification using NotificationManagerCompat
    }
}